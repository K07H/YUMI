#!/bin/sh
# YUMI's BepInEx start script.
#
# Description: This script is automatically configured by YUMI and its purpose
# is to start the game with BepInEx enabled. Compatible with BepInEx version 5.
#
# Version: 1.0.0
#
# Important note: You should not modify anything in this file (it is
# automatically configured by YUMI). If you need to modify something, or if the
# script is not working, please make an issue at https://github.com/K07H/YUMI or
# contact me directly (Email: <contact@osubmarin.fr> Discord: OSubMarin#0460).
#
# Usage:
# ./run_yumi_bepinex.sh
#
# Alternative usage:
# ./run_yumi_bepinex.sh <path to game> [doorstop arguments] [game arguments]
# NOTE: [doorstop arguments] allows you to override the following doorstop options:
#   - Enable/disable doorstop: Use argument "--doorstop_enabled" with value "0" or "1".
#     Example: --doorstop_enabled 0
#   - Doorstop target assembly: Use argument "--doorstop_target_assembly" with value "/path/to/target_assembly".
#     Example: --doorstop_target_assembly "/home/user/custom_assembly.dll"
#   - Doorstop DLL search path override: Use argument "--doorstop-mono-dll-search-path-override" with value "/path/to/core_libs".
#     Example: --doorstop-mono-dll-search-path-override "/home/user/custom_core_libs/"

# LINUX: The name of the Unity game executable.
# MACOS: The name of the game app folder, including the .app suffix.
executable_name=""

# Use POSIX-compatible way to get current script directory.
# This directory is also the game executable directory (unless BepInEx was not correcly installed).
a="/$0"; a=${a%/*}; a=${a#/}; a=${a:-.}; BASEDIR=$(cd "$a"; pwd -P)

# Initialize log file.
logfile="${BASEDIR}/run_yumi_bepinex.log"
currdate=$(date -u +"%Y/%m/%d %Hh%Mm%Ss UTC")
echo "---- ${currdate} ----" >> "$logfile"
echo "Received command: $@" >> "$logfile"

# If the program is launched via Steam, rerun the script via their bootstrapper to ensure Steam overlay works.
if [ "$2" = "SteamLaunch" ]; then
    echo "Program is launched via Steam: Rerunning script via bootstrapper." >> "$logfile"
    cmd="$1 $2 $3 $4 $0"
    shift 4
    exec $cmd $@
    exit
fi

# Writes given message to log file.
log_msg() {
    echo "$1" >> "$logfile"
}

# Writes given message to STD output and log file.
error_msg() {
    echo "$1"
    log_msg "$1"
}

# Converts common boolean strings into just "0" and "1".
doorstop_bool() {
    case $1 in
        TRUE|true|t|T|1|Y|y|yes)
            echo "1"
            ;;
        FALSE|false|f|F|0|N|n|no)
            echo "0"
            ;;
        *)
            # Simply return given string in case of unknown value (let the shell evaluate it).
            echo "$1"
            ;;
    esac
}

# Returns the absolute path to given file or directory.
abs_path() {
    dir_name=$(dirname "$1")
    base_name=$(basename "$1")
    ab_dirname=$(cd "$dir_name" && pwd)
    echo "${ab_dirname}/${base_name}"
}

# Returns the absolute path behind a symbolic link.
_readlink() {
    # Relative links with readlink (without -f) do not preserve the path info.
    ab_path=$(abs_path "$1")
    link=$(readlink "$ab_path")
    case $link in
        /*);;
        *)
            ab_dirpath=$(dirname "$ab_path")
            link="${ab_dirpath}/${link}"
            ;;
    esac
    echo "$link"
}

# Returns the absolute path to given executable.
resolve_executable_path() {
    exe_path=$(abs_path "$1")
    while [ -L "$exe_path" ]; do
        exe_path=$(_readlink "$exe_path");
    done
    echo "$exe_path"
}

# Whether or not to enable Doorstop. Valid values: TRUE or FALSE.
export DOORSTOP_ENABLE=TRUE

# What .NET assembly to execute. Valid value is a path to a .NET DLL that mono can execute.
export DOORSTOP_INVOKE_DLL_PATH="${BASEDIR}/BepInEx/core/BepInEx.Preloader.dll"

# If specified, Doorstop will load core libraries from this folder instead of the normal Managed folder.
# Mainly used to unstrip assemblies in some games.
export DOORSTOP_CORLIB_OVERRIDE_PATH=""

# Determine command and arguments.
# Allows to specify --doorstop-enable <true|false>, --doorstop-target <path/to/net_mono_.dll>, and --doorstop-dll-search-override <path/to/core/libraries>.
# Everything else is passed as-is to `exec`.
launch=""
rest=""
while :; do
    case $1 in
        --doorstop_enabled)
            if [ -n "$2" ]; then
                export DOORSTOP_ENABLE=$(doorstop_bool "$2")
                shift
            else
                log_msg "No --doorstop_enabled value specified, using default."
            fi
            ;;
        --doorstop_target_assembly)
            if [ -n "$2" ]; then
                export DOORSTOP_INVOKE_DLL_PATH="$2"
                shift
            else
                log_msg "No --doorstop_target_assembly value specified, using default."
            fi
            ;;
        --doorstop-mono-dll-search-path-override)
            if [ -n "$2" ]; then
                export DOORSTOP_CORLIB_OVERRIDE_PATH="$2"
                shift
            else
                log_msg "No --doorstop-mono-dll-search-path-override value specified, using default."
            fi
            ;;
        *)
            if [ -z "$1" ]; then
                break
            fi
            if [ -z "$launch" ]; then
                launch="$1"
                if [ -z "$executable_name" ] && [ -x "$1" ]; then
                    executable_name="$1"
                    log_msg "Target executable: $1"
                fi
            else
                rest="$rest $1"
            fi
            ;;
    esac
    shift
done
log_msg "Found launcher: $launch"
log_msg "Found arguments: $rest"

# Check if we have a valid executable name.
if [ -z "$executable_name" ] || [ ! -x "$executable_name" ]; then
    error_msg "Please open run_yumi_bepinex.sh in a text editor and set executable name."
    exit 1
fi

# Find operating system type.
os_type=$(uname -s)

# Find real path to the executable and DLLs extension based on operating system.
executable_path=""
lib_postfix=""
case $os_type in
    Linux*)
        executable_path="${BASEDIR}/${executable_name}"
        lib_postfix="so"
        log_msg "Identified Linux OS. Executable location: $executable_path"
        ;;
    Darwin*)
        executable_name=$(basename "$executable_name" .app)
        real_executable_name=$(defaults read "${BASEDIR}/${executable_name}.app/Contents/Info" CFBundleExecutable)
        executable_path="${BASEDIR}/${executable_name}.app/Contents/MacOS/${real_executable_name}"
        lib_postfix="dylib"
        log_msg "Identified Darwin OS. Executable location: $executable_path"
        ;;
    *)
        error_msg "Cannot identify OS (got ${os_type})! Please make an issue at https://github.com/NeighTools/UnityDoorstop"
        exit 1
        ;;
esac

# Find the absolute path to the executable.
executable_path=$(resolve_executable_path "$executable_path")
echo "$executable_path"
log_msg "Absolute path to the executable: $executable_path"

# Find the executable type.
executable_type=$(LD_PRELOAD="" file -b "$executable_path");

# Find the architecture (based on executable type).
arch=""
case $executable_type in
    *64-bit*)
        log_msg "Identified 64bits architecture."
        arch="x64"
        ;;
    *32-bit*)
        log_msg "Identified 32bits architecture."
        arch="x86"
        ;;
    *)
        error_msg "Cannot identify executable type (got ${executable_type})! Please make an issue at https://github.com/NeighTools/UnityDoorstop"
        exit 1
        ;;
esac

# Setup DLL injection.
doorstop_directory="${BASEDIR}/doorstop_libs/"
doorstop_libname="libdoorstop_${arch}.${lib_postfix}"
log_msg "Setting up DLL injection. DLL path: ${doorstop_directory}${doorstop_libname}"
export LD_LIBRARY_PATH="${doorstop_directory}:${LD_LIBRARY_PATH}"
if [ -z "$LD_PRELOAD" ]; then
    export LD_PRELOAD="${doorstop_libname}"
else
    export LD_PRELOAD="${doorstop_libname}:${LD_PRELOAD}"
fi
export DYLD_LIBRARY_PATH="${doorstop_directory}:${DYLD_LIBRARY_PATH}"
if [ -z "$DYLD_INSERT_LIBRARIES" ]; then
    export DYLD_INSERT_LIBRARIES="${doorstop_libname}"
else
    export DYLD_INSERT_LIBRARIES="${doorstop_libname}:${DYLD_INSERT_LIBRARIES}"
fi

# Run the main executable.
if [ -n "$launch" ]; then
    log_msg "Starting game. Command: $launch $rest"
# shellcheck disable=SC2086
    exec "$launch" $rest
else
    log_msg "Starting game. Command: $executable_path"
    exec "$executable_path"
fi
